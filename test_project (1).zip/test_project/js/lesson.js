const phoneInput = document.querySelector('#phone_input')
const phoneButton = document.querySelector('#phone_button')
const phoneResult = document.querySelector('#phone_result')

const phoneRegExp = /^\+996 \d{3} \d{2}-\d{2}-\d{2}$/

phoneButton.onclick = () => {
    if (phoneRegExp.test(phoneInput.value)) {
        phoneResult.innerHTML = 'Всё верно'
        phoneResult.style.color = 'green'
    } else {
        phoneResult.innerHTML = 'Некорректный номер телефона'
        phoneResult.style.color = 'red'
    }
}

const tabContentBlocks = document.querySelectorAll('.tab_content_block')
const tabContentItems = document.querySelectorAll('.tab_content_item')
const tabContentItemsParent = document.querySelector('.tab_content_items')

let currentTab = 0
let tabIntervalId = null

const hideTabContent = () => {
    tabContentBlocks.forEach((block) => {
        block.style.display = 'none'
    })
    tabContentItems.forEach((item) => {
        item.classList.remove('tab_content_item_active')
    })
}

const showTabContent = (index = 0) => {
    tabContentBlocks[index].style.display = 'flex'
    tabContentItems[index].classList.add('tab_content_item_active')
}

const startAutoTabs = () => {
    clearInterval(tabIntervalId)
    tabIntervalId = setInterval(() => {
        currentTab = currentTab < tabContentBlocks.length - 1 ? currentTab + 1 : 0
        hideTabContent()
        showTabContent(currentTab)
    }, 3000)
}

tabContentItemsParent.onclick = (event) => {
    if (event.target.classList.contains('tab_content_item')) {
        tabContentItems.forEach((item, index) => {
            if (event.target === item) {
                currentTab = index
                hideTabContent()
                showTabContent(currentTab)
                startAutoTabs()
            }
        })
    }
}

hideTabContent()
showTabContent(currentTab)
startAutoTabs()
